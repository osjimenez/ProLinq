﻿using System;

namespace ProLinq.Mapping
{
	internal struct MappingKey
	{
		private readonly Type _type1;
		private readonly Type _type2;

		public MappingKey(Type t1, Type t2)
		{
			_type1 = t1;
			_type2 = t2;
		}

		public bool Equals(MappingKey key)
		{
			if (key._type1 != _type1)
				return false;


			if (key._type2 != _type2)
				return false;

			return true;
		}

		public override bool Equals(object obj)
		{
			if (obj == null || obj.GetType() != GetType())
				return false;

			return Equals((MappingKey) obj);
		}

		public override int GetHashCode()
		{
			return _type1.GetHashCode() ^ _type2.GetHashCode();
		}
	}
}