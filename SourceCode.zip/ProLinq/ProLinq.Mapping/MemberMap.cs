﻿using System;
using System.Reflection;

namespace ProLinq.Mapping
{
	internal class MemberMap
	{
		public MemberInfo SourceMember { get; set; }
		public MemberInfo ResultMember { get; set; }
	}
}