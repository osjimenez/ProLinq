﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using ProLinq.Projection;

namespace ProLinq.PerformanceTests
{
	class Program
	{
		static void Main(string[] args)
		{
			var mapper = new ProLinq.Mapping.Mapper();


			var aList = new List<A>();
			for (Int32 i = 0; i < 100000; i++)
			{
				var a = new A
					{
						DataInt1 = 1,
						DataInt2 = 2,
						DataInt3 = 3,
						DataString1 = "4",
						DataString2 = "5"
					};
				a.OneMoreA = new A() {OneMoreA = a};
				aList.Add(a);
			}

			var sw = new Stopwatch();

			sw.Start();
			foreach (var a in aList)
			{
				var b = mapper.Map<A, B>(a);
			}
			sw.Stop();



			AutoMapper.Mapper.CreateMap<A, B>();
			var sw1 = new Stopwatch();
			sw1.Start();
			foreach (var a in aList)
			{
				var b = AutoMapper.Mapper.Map<A, B>(a);
			}
			sw1.Stop();
		}
	}
	

	public class A
	{
		public Int32 DataInt3;
		public String DataString1 { get; set; }
		public String DataString2 { get; set; }
		public Int32 DataInt1 { get; set; }
		public Int32 DataInt2 { get; set; }
		public A OneMoreA;
	}

	public class B
	{
		public Int32 DataInt2;
		public String DataString1 { get; set; }
		public String DataString3 { get; set; }
		public String DataInt1 { get; set; }
		public Int32 DataInt3 { get; set; }
		public B OneMoreA;
	}

	public class C
	{
		public Int32 DataInt2;

		public C(String dataString1)
		{
			DataString1 = dataString1;
		}

		public String DataString1 { get; private set; }
		public String DataString3 { get; set; }
		public String DataInt1 { get; set; }
		public Int32 DataInt3 { get; set; }
	}
}
