﻿using System;
using ProLinq.Sample.Data;

namespace ProLinq.Sample.BLL
{
	public class BusinessProduct
	{
		private readonly ProductManager manager;

		public BusinessProduct(ProductManager manager, Product product)
		{
			this.manager = manager;
			Id = product.Id;
			CategoryId = product.CategoryId;
			Name = product.Name;
			IsApproved = product.IsApproved;
			Price = product.Price;
		}

		public Int32 Id { get; private set; }
		public Int32 CategoryId { get; set; }
		public String Name { get; set; }
		public Decimal Price { get; set; }
		public Boolean IsApproved { get; set; }

		public Decimal DiscountPrice
		{
			get { return Price*0.9m; }
		}

		public void Save()
		{
			manager.SaveProduct(this);
		}
	}
}