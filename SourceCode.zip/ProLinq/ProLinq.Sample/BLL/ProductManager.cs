﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProLinq.Projection.Configuration.Fluent;
using ProLinq.Sample.Common;
using ProLinq.Sample.Data;
using ProLinq.Projection.Configuration;

namespace ProLinq.Sample.BLL
{
	public class ProductManager
	{
		protected IProductRepository ProductRepository { get; private set; }
		protected ISecurityContext SecurityContext { get; private set; }

		public ProductManager(IProductRepository productRepository, ISecurityContext securityContext)
		{
			ProductRepository = productRepository;
			SecurityContext = securityContext;
		}

		public IQueryable<BusinessProduct> GetProducts()
		{
			IQueryable<Product> products = ProductRepository.Get();

			products.Intercept(q =>
				{
					Trace.WriteLine("ProductRepository is being queried: " + q.Expression.ToString());
					return q.Execute();
				});

			if (!SecurityContext.IsAdmin)
			{
				products = products.Where(p => p.IsApproved);
			}

			return products.Project().To<BusinessProduct>(p => new BusinessProduct(this, p));
		}

		public void SaveProduct(BusinessProduct product)
		{
			throw  new NotImplementedException();
		}
	}
}
