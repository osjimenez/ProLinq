﻿using System;

namespace ProLinq.Sample.Common
{
	public interface ISecurityContext
	{
		Boolean IsAdmin { get; }
	}

	public class SecurityContext : ISecurityContext
	{
		#region ISecurityContext Members

		public bool IsAdmin { get; set; }

		#endregion
	}
}