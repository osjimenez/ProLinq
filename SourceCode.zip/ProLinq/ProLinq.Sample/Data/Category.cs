﻿using System;

namespace ProLinq.Sample.Data
{
	public class Category
	{
		public Int32 Id { get; set; }
		public String Name { get; set; }
	}
}