﻿using System;
using System.Data.Entity;
using System.Linq;

namespace ProLinq.Sample.Data
{
	public interface IProductRepository
	{
		IQueryable<Product> Get();
		void Add(Product p);
		void Update(Product p);
		void Remove(Product p);
	}

	public class ProductDbRepository : IProductRepository
	{
		private readonly DbSet<Product> productSet;

		public ProductDbRepository(DbSet<Product> productSet)
		{
			this.productSet = productSet;
		}

		#region IProductRepository Members

		public IQueryable<Product> Get()
		{
			return productSet.Intercept(q =>
				{
					//var sql = productSet.AsQueryable().Provider.CreateQuery(q.Expression);
					//Debug.WriteLine(sql.ToString());
					return q.Execute();
				});
		}

		public void Add(Product p)
		{
			throw new NotImplementedException();
		}

		public void Remove(Product p)
		{
			throw new NotImplementedException();
		}

		public void Update(Product p)
		{
			throw new NotImplementedException();
		}

		#endregion
	}
}