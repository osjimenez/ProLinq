﻿using System;

namespace ProLinq.Sample.Data
{
	public class Product
	{
		public Int32 Id { get; set; }
		public Int32 CategoryId { get; set; }
		public String Name { get; set; }
		public Decimal Price { get; set; }
		public Boolean IsApproved { get; set; }

		public virtual Category Category { get; set; }
	}
}