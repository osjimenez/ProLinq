﻿using System;
using System.Data.Entity;

namespace ProLinq.Sample.Data
{
	public class SampleDbContext : DbContext
	{
		public SampleDbContext()
			: base("LocalEntities")
		{
		}

		public DbSet<Product> Products { get; set; }
		public DbSet<Category> Categories { get; set; }
	}
}