﻿using System;
using System.Data.Entity;

namespace ProLinq.Sample.Data
{
	internal class SampleDbInitializer : CreateDatabaseIfNotExists<SampleDbContext>
	{
		protected override void Seed(SampleDbContext context)
		{
			context.Categories.Add(new Category
				{
					Id = 1,
					Name = "Food"
				});
			context.Categories.Add(new Category
				{
					Id = 2,
					Name = "Stuff"
				});
			context.Categories.Add(new Category
				{
					Id = 3,
					Name = "Other"
				});


			context.Products.Add(new Product
				{
					CategoryId = 1,
					Name = "Bread",
					Price = 1.20m,
					IsApproved = true
				});

			context.Products.Add(new Product
				{
					CategoryId = 1,
					Name = "Apples",
					Price = 1.80m,
					IsApproved = true
				});
			context.Products.Add(new Product
				{
					CategoryId = 1,
					Name = "Butter",
					Price = 1.50m,
					IsApproved = false
				});

			context.Products.Add(new Product
				{
					CategoryId = 2,
					Name = "Tooth brush",
					Price = 5.40m,
					IsApproved = true
				});

			context.SaveChanges();
		}
	}
}