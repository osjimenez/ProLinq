﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProLinq.Projection;
using ProLinq.Sample.BLL;
using ProLinq.Sample.Common;
using ProLinq.Sample.Data;

namespace ProLinq.Sample
{
	class Program
	{
		static void Main(string[] args)
		{
			Database.SetInitializer(new Data.SampleDbInitializer());

			var dbContext = new Data.SampleDbContext();
			var securityContext = new SecurityContext();
			var productRepository = new ProductDbRepository(dbContext.Products);
			var productManager = new ProductManager(productRepository, securityContext);

			var testFail = dbContext.Categories.Project().To<String>(c => FromCategory(c));
			var resf = testFail.Where(s => s.StartsWith("Fo")).FirstOrDefault();
			var prods = productManager.GetProducts();
			var res = (prods.Join(dbContext.Categories, p => new {Id = p.CategoryId, Val1 = "abc"},
			                      c => new {Id = c.Id, Val1 = "abc"}, (p, c) => new {p, c})
			                .Where(@t => @t.c.Name == "Food" && @t.p.DiscountPrice < 10)
			                .Select(@t1 => new
				                {
					                Int1 = @t1.p.Id,
					                Int2 = @t1.p.Price,
					                Appr = @t1.p.IsApproved
				                })).Where(x => !(x.Int1 < 0 || x.Int2 > 15))
							 .Select(x => new { Appr = x.Appr, Id1 = x.Int1, Cats = dbContext.Categories.Select(c=> c.Name)})
				             .Where(x => x.Appr).FirstOrDefault();


			var res2 = from p in prods
					   join c in dbContext.Categories on new { Id = p.CategoryId, Val1 = "abc" } equals
						   new { Id = c.Id, Val1 = "abc" }
					   where c.Name == "Food"
					   select p;

			var res3 = (from p in prods
					   select new MyTuple1
						   {
							   String1 = p.Name,
							   Int1 = (Int32)p.Price
						   }).Select(t => new MyTuple1
							   {
								   String2 = t.String1,
								   Int2 = t.Int1
							   });
			//res3.ToList();
		}

		private static String FromCategory(Category c)
		{
			return c.Name;
		}
	}


	class MyTuple1
	{
		public String String1;
		public String String2;
		public Int32 Int1;
		public Int32 Int2;
	}
}
