﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ProLinq.Tests.Helpers.Visitors
{
	class ConstantFinder : ExpressionVisitor
	{
		private Object _value;

		public Boolean Found { get; private set; }

		public ConstantFinder(Object value)
		{
			_value = value;
		}

		protected override Expression VisitConstant(ConstantExpression node)
		{
			if (node.Value.Equals(_value))
			{
				Found = true;
				return node;
			}
			return base.VisitConstant(node);
		}
	}
}
