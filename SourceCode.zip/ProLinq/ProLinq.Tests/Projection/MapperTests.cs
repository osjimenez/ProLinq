﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ProLinq.Projection;
using ProLinq.Projection.Configuration;

namespace ProLinq.Tests.Projection
{
	[TestClass]
	public class MapperTests
	{
		[TestMethod]
		public void ReturnsNullForNull()
		{
			var mapper = new ProjectionMapper();
			mapper.Projections.Add(new Projection<A, B>());
			var result = mapper.Map(null, typeof(A));
			Assert.AreEqual(null, result);
		}

		[TestMethod]
		public void ReturnsSourceWhenNoProjection()
		{
			var mapper = new ProjectionMapper();
			var source = new A();
			var result = mapper.Map(source, typeof(A));
			Assert.AreEqual(source, result);
		}

		[TestMethod]
		public void ReturnsMappedType()
		{
			var mapper = new ProjectionMapper();
			mapper.Projections.Add(new Projection<A, B>());
			var result = mapper.Map(new A(), typeof(B));
			Assert.IsInstanceOfType(result, typeof(B));
		}

		[TestMethod]
		public void ReturnsMappedCollectionForCollection()
		{
			var mapper = new ProjectionMapper();
			mapper.Projections.Add(new Projection<A, B>());
			var source = new A[] { new A(), new A() };
			var result = mapper.Map(source, typeof(Collection<B>));
			Assert.IsInstanceOfType(result, typeof(IEnumerable<B>));
		}
	}
}