﻿using System;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ProLinq.Projection.Visitors;
using ProLinq.Projection.Visitors.Optimization;
using ProLinq.Tests.Helpers;

namespace ProLinq.Tests.Projection
{
	[TestClass]
	public class OptimizationTests
	{
		[TestMethod]
		public void TestMethod1()
		{
			var source = new A[0].AsQueryable();
			var res = source.Intercept(q =>
					{
						var optimizator = new OptimizationVisitor();
						optimizator.OriginalExpression = q.Expression;
						optimizator.OriginalExpressionProcessedPart = source.Expression;
						optimizator.Projections = new ProLinq.Projection.Configuration.Projection[0];
						var newExpr = optimizator.Visit(source.Expression);

						Assert.IsTrue(newExpr.FindConstant(5));

						Assert.IsTrue(newExpr.FindConstant("abc"));

						return q.Execute();
					}).Where(b => b.DataString2.Contains("abc")).Select(b => b.DataInt3).FirstOrDefault(i => i > 5);
		}
	}
}
