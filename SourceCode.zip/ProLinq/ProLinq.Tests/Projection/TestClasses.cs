﻿using System;
using System.Collections.Generic;

namespace ProLinq.Tests.Projection
{
	/*
	 Adding or changing fields in the following classes can result in some tests being no longer valid, because they assume the classes structure.
	 Must be very careful here.
	 */

	public class A
	{
		public A()
		{
			Relations = new A[0];
		}

		public Int32 DataInt3;
		public String DataString1 { get; set; }
		public String DataString2 { get; set; }
		public Int32 DataInt1 { get; set; }
		public Int32 DataInt2 { get; set; }

		public IEnumerable<A> Relations { get; set; }
	}

	public class A1: A
	{
		public Int32 DataInt4;
	}

	public class B
	{
		public Int32 DataInt2;
		public String DataString1 { get; set; }
		public String DataString3 { get; set; }
		public String DataInt1 { get; set; }
		public Int32 DataInt3 { get; set; }
	}

	public class C
	{
		public Int32 DataInt2;

		public C(String dataString1)
		{
			DataString1 = dataString1;
		}

		public String DataString1 { get; private set; }
		public String DataString3 { get; set; }
		public String DataInt1 { get; set; }
		public Int32 DataInt3 { get; set; }
	}


	public class Temp1
	{
		public B B;
		public Int32 DataInt2;
		public String DataString1 { get; set; }
		public String DataString3 { get; set; }
		public String DataInt1 { get; set; }
		public Int32 DataInt3 { get; set; }
	}

	public class Temp2
	{
		public B B;
		public Int32 DataInt2;
		public String DataString1 { get; set; }
		public String DataString3 { get; set; }
		public String DataInt1 { get; set; }
		public Int32 DataInt3 { get; set; }
	}
}