﻿using System.Reflection;
using System.Runtime.InteropServices;


[assembly: AssemblyTitle("ProLinq.Tests")]
[assembly: AssemblyDescription("Tests for ProLinq")]
[assembly: AssemblyCompany("Dmitry Golubets")]
[assembly: AssemblyProduct("ProLinq")]
[assembly: AssemblyCopyright("Dmitry Golubets ©  2013")]
[assembly: ComVisible(false)]
[assembly: Guid("1b1f4e53-b4e8-41d6-a0cd-6a0612fa26f5")]

// vsrsions
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyConfiguration("Alpha")]