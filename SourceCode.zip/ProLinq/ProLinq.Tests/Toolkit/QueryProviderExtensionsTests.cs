﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using ProLinq.Toolkit;

namespace ProLinq.Tests.Toolkit
{
	[TestClass]
	public class QueryProviderExtensionsTests
	{
		[TestMethod]
		public void ExtensionCreateQueryOfTCallsCreateQuery()
		{

			var providerMock = new Mock<QueryProvider> {CallBase = true};
			var provider = providerMock.Object;
			var expression = Expression.Constant(null, typeof (IEnumerable<String>));

			provider.CreateQueryOfT(expression);
			providerMock.Verify(p => p.CreateQuery<String>(expression));
		}

		[TestMethod]
		public void ExtensionExecuteOfTCallsExecute()
		{

			var providerMock = new Mock<QueryProvider> { CallBase = true };
			var provider = providerMock.Object;
			var expression = Expression.Constant(null, typeof(String));

			provider.ExecuteOfT(expression);
			providerMock.Verify(p => p.Execute(expression));
		}
	}
}