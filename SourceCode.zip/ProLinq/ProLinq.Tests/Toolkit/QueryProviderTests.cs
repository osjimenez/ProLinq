﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using ProLinq.Toolkit;

namespace ProLinq.Tests.Toolkit
{
	[TestClass]
	public class QueryProviderTests
	{
		[TestMethod]
		public void ProviderCreateQueryCallsCreateQueryOfT()
		{
			IEnumerable<int> collection = Enumerable.Range(1, 100);
			Expression expression = collection.AsQueryable().Expression;

			var providerMock = new Mock<QueryProvider> {CallBase = true};
			;
			QueryProvider provider = providerMock.Object;

			provider.CreateQuery(expression);
			providerMock.Verify(p => p.CreateQuery<Int32>(expression));
		}

		[TestMethod]
		public void ProviderCreateQueryReturnsQuery()
		{
			IEnumerable<int> collection = Enumerable.Range(1, 100);
			Expression expression = collection.AsQueryable().Expression;

			var providerMock = new Mock<QueryProvider> {CallBase = true};
			QueryProvider provider = providerMock.Object;

			IQueryable query = provider.CreateQuery(expression);

			Assert.IsInstanceOfType(query, typeof (IQueryable<Int32>));
		}

		[TestMethod]
		public void ProviderExecuteOfTCallsExecute()
		{
			IEnumerable<int> collection = Enumerable.Range(1, 100);
			Expression expression = collection.AsQueryable().Expression;

			var providerMock = new Mock<QueryProvider> {CallBase = true};
			QueryProvider provider = providerMock.Object;

			provider.Execute<IEnumerable<Int32>>(expression);
			providerMock.Verify(p => p.Execute(expression));
		}
	}
}