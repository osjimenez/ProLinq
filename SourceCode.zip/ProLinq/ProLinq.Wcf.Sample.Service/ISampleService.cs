﻿using System;
using System.Linq;
using System.ServiceModel;
using ProLinq.Wcf.Sample.Service.Data;

namespace ProLinq.Wcf.Sample.Service
{
	[ServiceContract]
	public interface ISampleService
	{
		[OperationContract]
		IQueryable<Product> GetProducts();

		[OperationContract]
		IQueryable<Category> GetCategories();

		[OperationContract]
		void GetProductCountOut(out Int32 count);
	}
}
