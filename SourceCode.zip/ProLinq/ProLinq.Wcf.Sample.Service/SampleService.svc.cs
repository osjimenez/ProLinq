﻿using System;
using System.Linq;
using ProLinq.Wcf.Sample.Service.Data;

namespace ProLinq.Wcf.Sample.Service
{
	public class SampleService : ISampleService
	{
		private DatabaseEntities context = new Data.DatabaseEntities();

		#region ISampleService Members

		public IQueryable<Data.Product> GetProducts()
		{
			return this.context.Products;
		}

		public IQueryable<Data.Category> GetCategories()
		{
			return this.context.Categories;
		}


		public void GetProductCountOut(out int count)
		{
			count = this.context.Products.Count();
		}

		#endregion
	}
}
