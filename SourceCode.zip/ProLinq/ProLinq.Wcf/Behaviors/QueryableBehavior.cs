﻿using System;
using System.Collections.ObjectModel;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.ServiceModel.Dispatcher;
using ProLinq.Wcf.Configuration;
using ProLinq.Wcf.Description;

namespace ProLinq.Wcf.Behaviors
{
	/// <summary>
	/// WCF behavior for IQueryable.
	/// Can be applied to services and endpoints.
	/// </summary>
	public class QueryableBehavior : Attribute, IServiceBehavior, IEndpointBehavior
	{
		#region Fields

		private Settings _settings;

		#endregion

		#region Constructors

		public QueryableBehavior()
		{
			this._settings = new Settings();
		}

		internal QueryableBehavior(Settings settings)
		{
			this._settings = settings;
		}

		#endregion

		#region IServiceBehavior Members

		public void AddBindingParameters(ServiceDescription serviceDescription, ServiceHostBase serviceHostBase,
		                                 Collection<ServiceEndpoint> endpoints, BindingParameterCollection bindingParameters)
		{
		}

		public void ApplyDispatchBehavior(ServiceDescription serviceDescription, ServiceHostBase serviceHostBase)
		{
		}

		public void Validate(ServiceDescription serviceDescription, ServiceHostBase serviceHostBase)
		{
			new QueryableDescriptionMutator(this._settings).AlterDescription(serviceDescription);
		}

		#endregion

		#region IEndpointBehavior Members

		public void AddBindingParameters(ServiceEndpoint endpoint, BindingParameterCollection bindingParameters)
		{
			
		}

		public void ApplyClientBehavior(ServiceEndpoint endpoint, ClientRuntime clientRuntime)
		{
		}

		public void ApplyDispatchBehavior(ServiceEndpoint endpoint, EndpointDispatcher endpointDispatcher)
		{
		}

		public void Validate(ServiceEndpoint endpoint)
		{
			new QueryableDescriptionMutator(this._settings).AlterDescription(endpoint.Contract);
		}

		#endregion

	}
}