﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel.Description;
using System.Xml;
using ProLinq.Wcf.Runtime;

namespace ProLinq.Wcf.Behaviors
{
	internal class QueryableDataContractSerializerOperationBehavior : DataContractSerializerOperationBehavior
	{
		public QueryableDataContractSerializerOperationBehavior(OperationDescription operationDescription)
			: base(operationDescription)
		{

		}

		public override XmlObjectSerializer CreateSerializer(Type type, string name, string ns, IList<Type> knownTypes)
		{
			return new DataContractSerializer(type, name, ns, knownTypes, Int32.MaxValue, false, true,
											  null, new SharedTypeResolver(this.DataContractResolver));
		}

		public override XmlObjectSerializer CreateSerializer(Type type, XmlDictionaryString name, XmlDictionaryString ns,
		                                                     IList<Type> knownTypes)
		{
			return new DataContractSerializer(type, name, ns, knownTypes, Int32.MaxValue, false, true,
											  null, new SharedTypeResolver(this.DataContractResolver));
		}
	}
}