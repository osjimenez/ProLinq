﻿using System;
using System.ServiceModel.Description;
using ProLinq.Wcf.Configuration;
using ProLinq.Wcf.Runtime;

namespace ProLinq.Wcf.Behaviors
{
	class QueryableOperationBehavior : IOperationBehavior
	{
		private Settings _settings;

		public QueryableOperationBehavior(Settings settings)
		{
			this._settings = settings;
		}

		#region IOperationBehavior Members

		public void AddBindingParameters(OperationDescription operationDescription, System.ServiceModel.Channels.BindingParameterCollection bindingParameters)
		{
		}

		public void ApplyClientBehavior(OperationDescription operationDescription, System.ServiceModel.Dispatcher.ClientOperation clientOperation)
		{
		}

		public void ApplyDispatchBehavior(OperationDescription operationDescription, System.ServiceModel.Dispatcher.DispatchOperation dispatchOperation)
		{
			dispatchOperation.Invoker = new QueryableOperationInvoker(dispatchOperation.Invoker, operationDescription.DeclaringContract.ContractType, this._settings);
		}

		public void Validate(OperationDescription operationDescription)
		{
		}

		#endregion
	}
}
