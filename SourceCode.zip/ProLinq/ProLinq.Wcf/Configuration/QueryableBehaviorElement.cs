﻿using System;
using System.ServiceModel.Configuration;
using ProLinq.Wcf.Behaviors;

namespace ProLinq.Wcf.Configuration
{
	public class QueryableBehaviorElement : BehaviorExtensionElement
	{
		public override Type BehaviorType
		{
			get { return typeof (QueryableBehavior); }
		}

		protected override object CreateBehavior()
		{
			return new QueryableBehavior();
		}
	}
}