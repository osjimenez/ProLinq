﻿using System;
using ProLinq.Wcf.Linq.Expressions.Serialization;

namespace ProLinq.Wcf.Configuration
{
	/// <summary>
	/// Settings.
	/// </summary>
	internal class Settings
	{
		internal Settings()
		{
			this.ExpressionSerializer = new ZippedJsonExpressionSerializer();
		}

		/// <summary>
		/// Gets or sets expression serializer.
		/// </summary>
		public IExpressionSerializer ExpressionSerializer { get; set; }
	}
}