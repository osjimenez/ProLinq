﻿using System;
using System.Collections;
using System.Linq;
using System.Linq.Expressions;
using System.Runtime.Serialization;

namespace ProLinq.Wcf.Description
{
	/// <summary>
	/// Surrogate contract for IQueryable
	/// </summary>
	[DataContract]
	internal class QueryResult : IQueryable
	{
		[DataMember]
		public Object Result { get; set; }

		#region IQueryable Members

		public Type ElementType
		{
			get { throw new NotImplementedException(); }
		}

		public Expression Expression
		{
			get { throw new NotImplementedException(); }
		}

		public IQueryProvider Provider
		{
			get { throw new NotImplementedException(); }
		}

		#endregion

		#region IEnumerable Members

		public IEnumerator GetEnumerator()
		{
			throw new NotImplementedException();
		}

		#endregion
	}
}