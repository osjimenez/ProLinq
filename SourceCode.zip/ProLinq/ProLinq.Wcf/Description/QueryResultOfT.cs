﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;

namespace ProLinq.Wcf.Description
{
	/// <summary>
	/// Surrogate contract for IQueryable&lt;T&gt;
	/// </summary>
	/// <typeparam name="T"></typeparam>
	[DataContract]
	internal class QueryResult<T> : QueryResult, IQueryable<T>
	{
		#region IEnumerable<T> Members

		public new IEnumerator<T> GetEnumerator()
		{
			throw new NotImplementedException();
		}

		#endregion
	}
}