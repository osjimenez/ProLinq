﻿using System;
using System.ServiceModel.Description;

namespace ProLinq.Wcf.Description
{
	class ServiceDescriptionMutator
	{
		public virtual void AlterDescription(ServiceDescription serviceDescription)
		{
			foreach (var endpoint in serviceDescription.Endpoints)
			{
				this.AlterDescription(endpoint.Contract);
			}
		}

		public virtual void AlterDescription(ServiceEndpoint endpoint)
		{
			this.AlterDescription(endpoint.Contract);
		}

		public virtual void AlterDescription(ContractDescription contractDescription)
		{
			foreach (var operation in contractDescription.Operations)
			{
				this.AlterDescription(operation);
			}
		}

		public virtual void AlterDescription(OperationDescription operationDescription)
		{

		}
	}
}
