﻿using System;
using System.ServiceModel;
using ProLinq.Wcf.Behaviors;

namespace ProLinq.Wcf.Extensions
{
	public static class ServiceHostExtensions
	{
		/// <summary>
		/// Ensures host has proper configuration
		/// </summary>
		/// <param name="factory"></param>
		internal static void ApplyQueryableBehavior(this ServiceHost host)
		{
			if (host.Description.Behaviors.Find<QueryableBehavior>() == null)
			{
				host.Description.Behaviors.Add(new QueryableBehavior());
			}
		}
	}
}