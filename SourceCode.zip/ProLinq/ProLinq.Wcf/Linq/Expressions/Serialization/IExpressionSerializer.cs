﻿using System;
using System.Linq.Expressions;

namespace ProLinq.Wcf.Linq.Expressions.Serialization
{
	internal interface IExpressionSerializer
	{
		Byte[] Serialize(Expression expression);
		Expression Deserialize(Byte[] bytes);
	}
}