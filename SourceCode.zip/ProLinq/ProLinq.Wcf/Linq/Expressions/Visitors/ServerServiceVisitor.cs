﻿using System;
using System.Linq.Expressions;

namespace ProLinq.Wcf.Linq.Expressions.Visitors
{
	internal class ServerServiceVisitor : ExpressionVisitor
	{
		public Object ServiceInstance { get; set; }
		public Type ServiceType { get; set; }

		protected override Expression VisitConstant(ConstantExpression node)
		{
			if (node.Type == this.ServiceType)
			{
				return Expression.Constant(this.ServiceInstance, this.ServiceType);
			}
			return base.VisitConstant(node);
		}
	}
}