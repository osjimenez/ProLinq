﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel.Description;
using System.Text;
using System.Threading.Tasks;

namespace ProLinq.Wcf.Helpers
{
	class ServiceDescriptionMutator
	{
		public virtual void AlterDescription(ServiceDescription serviceDescription)
		{
			foreach (var endpoint in serviceDescription.Endpoints)
			{
				AlterDescription(endpoint.Contract);
			}
		}

		public virtual void AlterDescription(ServiceEndpoint endpoint)
		{
			AlterDescription(endpoint.Contract);
		}

		public virtual void AlterDescription(ContractDescription contractDescription)
		{
			foreach (var operation in contractDescription.Operations)
			{
				AlterDescription(operation);
			}
		}

		public virtual void AlterDescription(OperationDescription operationDescription)
		{

		}
	}
}
