﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ProLinq.Wcf")]
[assembly: AssemblyDescription("A library that allows use of IQueryable in WCF web service.")]
[assembly: AssemblyCompany("Dmitry Golubets")]
[assembly: AssemblyProduct("ProLinq.Wcf")]
[assembly: AssemblyCopyright("Dmitry Golubets ©  2013")]
[assembly: ComVisible(false)]
[assembly: Guid("7c2df46f-f8aa-4d8f-82c9-19a07aa872bb")]

// versions
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.6")]
[assembly: AssemblyInformationalVersion("1.0.6")]