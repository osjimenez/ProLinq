﻿using System;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using ProLinq.Wcf.Configuration;
using ProLinq.Wcf.Extensions;

namespace ProLinq.Wcf
{
	/// <summary>
	/// WCF channel factory for queryable services.
	/// </summary>
	/// <typeparam name="T">Service contract type</typeparam>
	public class QueryableChannelFactory<T> : ChannelFactory<T>
	{
		#region Fields

		private readonly Settings _settings = new Settings();

		#endregion

		#region Constructors

		public QueryableChannelFactory()
		{
		}

		public QueryableChannelFactory(Binding binding)
			: base(binding)
		{
		}

		public QueryableChannelFactory(Binding binding, EndpointAddress address)
			: base(binding, address)
		{
		}

		public QueryableChannelFactory(ServiceEndpoint endpoint)
			: base(endpoint)
		{
		}

		public QueryableChannelFactory(String endpointConfigurationName)
			: base(endpointConfigurationName)
		{
		}

		#endregion

		#region Properties

		internal Settings Settings
		{
			get { return this._settings; }
		}

		#endregion

		#region Methods

		protected override void ApplyConfiguration(string configurationName)
		{
			base.ApplyConfiguration(configurationName);
			this.ApplyQueryableBehavior();
		}

		public override T CreateChannel(EndpointAddress address, Uri via)
		{
			var baseChannel = base.CreateChannel(address, via);
			return ChannelExtensions.WrapChannel(baseChannel);
		}

		#endregion
	}
}