﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel.Description;
using System.Xml;

namespace ProLinq.Wcf
{
	internal class QueryableDataContractSerializerOperationBehavior : DataContractSerializerOperationBehavior
	{
		private IExpressionSerializer _expressionSerializer;

		public QueryableDataContractSerializerOperationBehavior(OperationDescription operationDescription, IExpressionSerializer serializer)
			: base(operationDescription)
		{
			_expressionSerializer = serializer;
		}

		public override XmlObjectSerializer CreateSerializer(Type type, string name, string ns, IList<Type> knownTypes)
		{
			return new DataContractSerializer(type, name, ns, knownTypes, Int32.MaxValue, false, true, new QueryableSurrogate(_expressionSerializer));
		}

		public override XmlObjectSerializer CreateSerializer(Type type, XmlDictionaryString name, XmlDictionaryString ns, IList<Type> knownTypes)
		{
			return new DataContractSerializer(type, name, ns, knownTypes, Int32.MaxValue, false, true, new QueryableSurrogate(_expressionSerializer));
		}
	}
}