﻿using System;
using System.ServiceModel;
using System.ServiceModel.Description;
using ProLinq.Wcf.Configuration;
using ProLinq.Wcf.Description;

namespace ProLinq.Wcf
{
	/// <summary>
	/// WCF service host for queryable services.
	/// </summary>
	public class QueryableServiceHost : ServiceHost
	{
		#region Fields

		private Settings _settings = new Settings();

		#endregion

		#region Constructors

		public QueryableServiceHost()
		{
		}

		public QueryableServiceHost(Object singletonInstance, params Uri[] baseAddresses)
			: base(singletonInstance, baseAddresses)
		{
		}

		public QueryableServiceHost(Type serviceType, params Uri[] baseAddresses)
			: base(serviceType, baseAddresses)
		{
		}

		#endregion

		#region Methods

		protected override void ApplyConfiguration()
		{
			base.ApplyConfiguration();

			var mutator = new QueryableDescriptionMutator(this._settings);
			mutator.AlterDescription(this.Description);
		}

		public override System.Collections.ObjectModel.ReadOnlyCollection<ServiceEndpoint> AddDefaultEndpoints()
		{
			var mutator = new QueryableDescriptionMutator(this._settings);
			var defaultEndpoints = base.AddDefaultEndpoints();

			foreach (var endpoint in defaultEndpoints)
			{
				mutator.AlterDescription(endpoint.Contract);
			}

			return defaultEndpoints;
		}

		#endregion
	}
}