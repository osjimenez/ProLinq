﻿using System;
using System.ServiceModel.Activation;

namespace ProLinq.Wcf
{
	/// <summary>
	/// WCF service host factory for queryable services.
	/// </summary>
	public class QueryableServiceHostFactory : ServiceHostFactory
	{
		protected override System.ServiceModel.ServiceHost CreateServiceHost(Type serviceType, Uri[] baseAddresses)
		{
			return new QueryableServiceHost(serviceType, baseAddresses);
		}
	}
}