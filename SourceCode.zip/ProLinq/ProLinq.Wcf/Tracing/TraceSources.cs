﻿using System;
using System.Diagnostics;

namespace ProLinq.Wcf.Tracing
{
	internal static class TraceSources
	{
		internal static readonly TraceSource WCF = new TraceSource("ProLinq.Wcf", SourceLevels.All);
	}
}