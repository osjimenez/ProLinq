﻿using System;
using System.Linq.Expressions;
using ProLinq.Toolkit;

namespace ProLinq.Interception
{
	/// <summary>
	///     A wrapper for the intercepted query.
	/// </summary>
	public class InterceptedQuery
	{
		internal InterceptedQuery(Expression expression, Func<Expression, Object> action)
		{
			Expression = expression;
			ExecuteAction = action;
		}

		internal Func<Expression, Object> ExecuteAction { get; private set; }

		public Boolean IsCollection
		{
			get { return Expression.Type.IsEnumerable(); }
		}

		/// <summary>
		///     Expression passed for query execution.
		///     Can be modified before a call to Execute.
		/// </summary>
		public Expression Expression { get; set; }

		/// <summary>
		///     Executes base query.
		/// </summary>
		/// <returns></returns>
		public Object Execute()
		{
			return ExecuteAction(Expression);
		}
	}
}