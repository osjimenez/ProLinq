﻿using System;

namespace ProLinq.Interception
{
	/// <summary>
	///     Delegate for query execution interception
	/// </summary>
	/// <param name="query"></param>
	/// <returns></returns>
	public delegate Object InterceptionAction(InterceptedQuery query);
}