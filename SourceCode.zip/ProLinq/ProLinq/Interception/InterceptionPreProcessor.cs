﻿using System.Linq;
using System.Linq.Expressions;
using ProLinq.Toolkit;

namespace ProLinq.Interception
{
	/// <summary>
	///     Preprocessing of an intercepted expression
	/// </summary>
	internal class InterceptionPreProcessor : ExpressionVisitor
	{
		public IQueryable Source { get; set; }

		protected override Expression VisitConstant(ConstantExpression node)
		{
			if (node.Type.Is(typeof (InterceptionQuery<>)))
			{
				var provider = (InterceptionQueryProvider) (((IQueryable) node.Value).Provider);
				return provider.Source.Expression;
			}

			return base.VisitConstant(node);
		}
	}
}