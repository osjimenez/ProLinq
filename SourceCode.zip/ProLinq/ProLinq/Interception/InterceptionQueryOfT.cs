﻿using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using ProLinq.Toolkit;

namespace ProLinq.Interception
{
	internal class InterceptionQuery<T> : Query<T>, IInterceptionQuery
	{
		#region Constructors

		public InterceptionQuery(IQueryable source)
			: base(new InterceptionQueryProvider(source))
		{
		}

		public InterceptionQuery(QueryProvider provider, Expression expression)
			: base(provider, expression)
		{
		}

		#endregion

		#region Properties

		public List<InterceptionAction> Actions
		{
			get { return ((InterceptionQueryProvider) Provider).Actions; }
		}

		#endregion
	}
}