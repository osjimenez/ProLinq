﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProLinq.Mapping
{
	internal abstract class MappingConfiguration
	{
		public Boolean IsCompiled { get; private set; }

		public void Compile()
		{
			if (!IsCompiled)
			{
				CompileInternal();
				IsCompiled = true;
			}
		}

		protected abstract void CompileInternal();
	}
}
