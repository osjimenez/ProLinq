﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProLinq.Mapping
{
	internal class MappingKeyComparer : IEqualityComparer<MappingKey>
	{
		#region IEqualityComparer<CompositeKey> Members

		public bool Equals(MappingKey x, MappingKey y)
		{
			return x.Equals(y);
		}

		public int GetHashCode(MappingKey obj)
		{
			return obj.GetHashCode();
		}

		#endregion
	}
}
