using System;
using System.Linq.Expressions;

namespace ProLinq.Projection.Configuration
{
	/// <summary>
	///     An interface for configuration factory.
	///     Use this interface to implement your own configuration factory then set it to ProjectionConfigurationFactory.Instance.
	/// </summary>
	public interface IProjectionConfigurationFactory
	{
		ProjectionConfiguration CreateConfiguration();

		ProjectionConfiguration<TSource, TResult> CreateConfiguration<TSource, TResult>(
			Expression<Func<TSource, TResult>> factory);

		ProjectionConfiguration<TSource, TResult> CreateConfiguration<TSource, TResult>();
	}
}