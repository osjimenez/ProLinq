﻿using System;
using System.Linq;
using System.Linq.Expressions;

namespace ProLinq.Projection.Configuration
{
	/// <summary>
	///     Allows to perform project call using only one generic parameter
	/// </summary>
	/// <typeparam name="TSource"></typeparam>
	public interface IProjectionSource<TSource>
	{
		IQueryable<TResult> To<TResult>(ProjectionConfiguration<TSource, TResult> configuration);
		IQueryable<TResult> To<TResult>(Expression<Func<TSource, TResult>> factory);
		IQueryable<TResult> To<TResult>()
			where TResult : new();

		IQueryable<TResult> To<TResult>(Action<ProjectionConfiguration<TSource, TResult>> configure);
		IQueryable<TResult> To<TResult>(Expression<Func<TSource, TResult>> factory, Action<ProjectionConfiguration<TSource, TResult>> configure);
	}
}