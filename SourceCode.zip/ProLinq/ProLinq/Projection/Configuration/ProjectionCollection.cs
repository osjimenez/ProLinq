﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProLinq.Projection.Configuration
{
	internal class ProjectionCollection : Collection<Projection>
	{
		internal event EventHandler<ProjectionCollectionEventArgs> Deleting;

		protected override void RemoveItem(int index)
		{
			if (Deleting != null)
			{
				Deleting(this, new ProjectionCollectionEventArgs(this[index]));
			}

			base.RemoveItem(index);
		}
	}
}
