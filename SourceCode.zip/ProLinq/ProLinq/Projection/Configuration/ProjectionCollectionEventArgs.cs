﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProLinq.Projection.Configuration
{
	class ProjectionCollectionEventArgs : EventArgs
	{
		public ProjectionCollectionEventArgs(Projection projection)
		{
			Projection = projection;
		}

		public Projection Projection { get; private set; }
	}
}
