﻿using System;

namespace ProLinq.Projection.Configuration
{
	/// <summary>
	///     Projection configuration between two types
	/// </summary>
	/// <typeparam name="TSource"></typeparam>
	/// <typeparam name="TResult"></typeparam>
	public class ProjectionConfiguration<TSource, TResult> : ProjectionConfiguration
	{
		private Projection<TSource, TResult> _mainProjection;

		public ProjectionConfiguration()
		{
			this._mainProjection = new Projection<TSource, TResult>();
			this.ProjectionsInternal.Add(this._mainProjection);
			this.ProjectionsInternal.Deleting += this.ProjectionsInternal_Deleting;
		}

		private void ProjectionsInternal_Deleting(object sender, ProjectionCollectionEventArgs e)
		{
			if (e.Projection == this._mainProjection)
			{
				throw new InvalidOperationException("Main projection cannot be deleted");
			}
		}

		public Projection<TSource, TResult> MainProjection
		{
			get { return this._mainProjection; }
		}
	}
}