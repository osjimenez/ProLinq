﻿using System;

namespace ProLinq.Projection.Configuration
{
	/// <summary>
	/// 
	/// </summary>
	/// <typeparam name="TSource"></typeparam>
	/// <typeparam name="TResult"></typeparam>
	public class Projection<TSource, TResult> : Projection
	{
		public Projection()
			: base(typeof(TSource), typeof(TResult))
		{
		}

		/// <summary>
		/// Gets or sets a factory for creating the result type out of source type. 
		/// </summary>
		public new Func<TSource, TResult> Factory
		{
			get { return (Func<TSource, TResult>)base.Factory; }
			set { base.Factory = value; }
		}
	}
}
