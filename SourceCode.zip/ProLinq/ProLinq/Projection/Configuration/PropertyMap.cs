﻿using System;
using System.Reflection;

namespace ProLinq.Projection.Configuration
{
	/// <summary>
	/// Describes a correlation between two properties of different types.
	/// </summary>
	public class PropertyMap
	{
		public PropertyMap(MemberInfo sourceProperty, MemberInfo destinationProperty)
		{
			this.SourceProperty = sourceProperty;
			this.DestinationProperty = destinationProperty;
		}

		/// <summary>
		/// Source member
		/// </summary>
		public MemberInfo SourceProperty { get; private set; }

		/// <summary>
		/// Destination member
		/// </summary>
		public MemberInfo DestinationProperty { get; private set; }
	}
}