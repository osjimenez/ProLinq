﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace ProLinq.Projection.Configuration
{
	/// <summary>
	/// Collection of property maps between two types
	/// </summary>
	internal class PropertyMapCollection : Collection<PropertyMap>
	{
		private readonly Type _resultType;
		private readonly Type _sourceType;

		internal PropertyMapCollection(Type sourceType, Type resultType)
		{
			this._sourceType = sourceType;
			this._resultType = resultType;
		}

		internal PropertyMapCollection(Type sourceType, Type resultType, IList<PropertyMap> maps)
			: base(maps)
		{
			this._sourceType = sourceType;
			this._resultType = resultType;
		}

		protected override void InsertItem(int index, PropertyMap item)
		{
			if (item.SourceProperty.DeclaringType != this._sourceType)
				throw new ArgumentException(String.Format("SourceProperty doesn't belong to type {0}", this._sourceType));
			if (item.DestinationProperty.DeclaringType != this._resultType)
				throw new ArgumentException(String.Format("DestinationProperty doesn't belong to type {0}", this._resultType));

			base.InsertItem(index, item);
		}
	}
}