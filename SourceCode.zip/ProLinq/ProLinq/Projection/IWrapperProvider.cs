﻿using System.Linq;

namespace ProLinq.Projection
{
	internal interface IWrapperProvider
	{
		IQueryable Source { get; }
	}
}