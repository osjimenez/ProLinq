﻿using System;

namespace ProLinq.Projection
{
	/*
	 * Clasess for temporarary replacement of anonymous types during projection
	 */

	[Serializable]
	internal class MutableTuple<T1>
	{
		public T1 Item1 { get; set; }
	}

	[Serializable]
	internal class MutableTuple<T1, T2>
	{
		public T1 Item1 { get; set; }
		public T2 Item2 { get; set; }
	}

	[Serializable]
	internal class MutableTuple<T1, T2, T3>
	{
		public T1 Item1 { get; set; }
		public T2 Item2 { get; set; }
		public T3 Item3 { get; set; }
	}

	[Serializable]
	internal class MutableTuple<T1, T2, T3, T4>
	{
		public T1 Item1 { get; set; }
		public T2 Item2 { get; set; }
		public T3 Item3 { get; set; }
		public T4 Item4 { get; set; }
	}

	[Serializable]
	internal class MutableTuple<T1, T2, T3, T4, T5>
	{
		public T1 Item1 { get; set; }
		public T2 Item2 { get; set; }
		public T3 Item3 { get; set; }
		public T4 Item4 { get; set; }
		public T5 Item5 { get; set; }
	}

	[Serializable]
	internal class MutableTuple<T1, T2, T3, T4, T5, T6>
	{
		public T1 Item1 { get; set; }
		public T2 Item2 { get; set; }
		public T3 Item3 { get; set; }
		public T4 Item4 { get; set; }
		public T5 Item5 { get; set; }
		public T6 Item6 { get; set; }
	}

	[Serializable]
	internal class MutableTuple<T1, T2, T3, T4, T5, T6, T7>
	{
		public T1 Item1 { get; set; }
		public T2 Item2 { get; set; }
		public T3 Item3 { get; set; }
		public T4 Item4 { get; set; }
		public T5 Item5 { get; set; }
		public T6 Item6 { get; set; }
		public T7 Item7 { get; set; }
	}

	[Serializable]
	internal class MutableTuple<T1, T2, T3, T4, T5, T6, T7, T8>
	{
		public T1 Item1 { get; set; }
		public T2 Item2 { get; set; }
		public T3 Item3 { get; set; }
		public T4 Item4 { get; set; }
		public T5 Item5 { get; set; }
		public T6 Item6 { get; set; }
		public T7 Item7 { get; set; }
		public T8 Item8 { get; set; }
	}
}