﻿using System;
using System.Linq.Expressions;

namespace ProLinq.Projection.Visitors
{
	internal class PostProcessingVisitor : ExpressionVisitor
	{
		private readonly Expression _newSource;
		private readonly Expression _processedExpression;

		public PostProcessingVisitor(Expression processedExpression, Expression newSource)
		{
			this._processedExpression = processedExpression;
			this._newSource = newSource;
		}

		public override Expression Visit(Expression node)
		{
			if (node == this._processedExpression)
			{
				return this._newSource;
			}
			return base.Visit(node);
		}
	}
}