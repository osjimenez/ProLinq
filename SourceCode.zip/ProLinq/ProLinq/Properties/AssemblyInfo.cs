﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ProLinq")]
[assembly: AssemblyDescription("A library with IQueryable extensions.")]
[assembly: AssemblyCompany("Dmitry Golubets")]
[assembly: AssemblyProduct("ProLinq")]
[assembly: AssemblyCopyright("Dmitry Golubets ©  2013")]
[assembly: ComVisible(false)]
[assembly: Guid("ca4514c0-1a5a-46f2-bdbc-1cd3aca758a4")]

// visible to tests
[assembly:
	InternalsVisibleTo(
		"ProLinq.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100e5cb1677b932e38f8f025f053a2646a39ccb085d81a50eb589f06bd880344e6dbaaf69ccac4ef642d573e259f65115096bea1312e3d4f0e2378a4b8a3bb9a0ec7b08d9d79b12007a9a581044cdbee1bcffb12bca94b953cc64c3066252c980294c9cfb7fba939b3c1407bdb52f8072221d26005df1f63c02cb8340fc829015bc"
		)]

// versions
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.4")]
[assembly: AssemblyInformationalVersion("1.0.4")]