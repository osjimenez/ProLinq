﻿using System;
using System.Linq.Expressions;

namespace ProLinq.Toolkit
{
	internal class DelegateQueryProvider : QueryProvider
	{
		private readonly Func<Expression, Object> _execute;

		public DelegateQueryProvider(Func<Expression, Object> execute)
		{
			if (execute == null)
				throw new ArgumentNullException();

			_execute = execute;
		}

		public override object Execute(Expression expression)
		{
			return _execute(expression);
		}
	}
}