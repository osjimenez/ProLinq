﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ProLinq.Toolkit.Expressions
{
	static class ExpressionExtensions
	{
		public static MemberInfo GetMemberInfo(this Expression expression)
		{
			var memberExpression = expression as MemberExpression;
			if (memberExpression != null)
			{
				return memberExpression.Member;
			}

			var unaryExpression = expression as UnaryExpression;
			if (unaryExpression != null)
			{
				return unaryExpression.Operand.GetMemberInfo();
			}

			var lambdaExpression = expression as LambdaExpression;
			if (lambdaExpression != null)
			{
				return lambdaExpression.Body.GetMemberInfo();
			}

			return null;
		}
	}
}
