﻿using System;
using System.Collections;
using System.Linq;
using System.Linq.Expressions;

namespace ProLinq.Toolkit
{
	/// <summary>
	/// Helper methods for Query&lt;T&gt;.
	/// </summary>
	public static class Query
	{
		#region Static

		public static IQueryable Create(Type elementType, QueryProvider provider)
		{
			var queryType = typeof (Query<>).MakeGenericType(elementType);
			return (IQueryable) Activator.CreateInstance(queryType, provider);
		}

		internal static IQueryable Create(Type queryType, Type elementType, QueryProvider provider)
		{
			var queryGenericType = queryType.MakeGenericType(elementType);
			return (IQueryable)Activator.CreateInstance(queryGenericType, provider);
		}

		public static IQueryable Define(Type elementType, Func<Expression, Object> execute)
		{
			return Create(elementType, new DelegateQueryProvider(execute));
		}

		public static IQueryable<T> Define<T>(Func<Expression, Object> execute)
		{
			return new Query<T>(new DelegateQueryProvider(execute));
		}

		#endregion

	}
}