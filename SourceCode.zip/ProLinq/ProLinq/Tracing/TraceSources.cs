﻿using System.Diagnostics;

namespace ProLinq.Tracing
{
	internal static class TraceSources
	{
		internal static readonly TraceSource Projection = new TraceSource("ProLinq.Projection", SourceLevels.All);
	}
}